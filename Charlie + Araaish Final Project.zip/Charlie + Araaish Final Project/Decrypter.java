import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

//Charlie
public class Decrypter  {
	

	
	private ArrayList <String> string;
	
	public static void generate(File inputfile) throws FileNotFoundException{
	Scanner scan = new Scanner(inputfile);
		for (int i = 0; i < 25; i++) {
		}
	}
	
	public static String shift(String input, int shift) {
		int length = input.length();
		String newString = "";
		boolean replace = false;
		int newChar = 0;
		for (int i = 0; i < length; i++) {
			replace = false;
			char firstChar = input.charAt(i);
				if (firstChar > 64 && firstChar < 91) {
					newChar = firstChar + shift;
					if (newChar > 90) 
						newChar -= 26;
					replace = true;
				}
				if (firstChar > 96 && firstChar < 123) {
					newChar = firstChar + shift;
					if (newChar > 122) 
						newChar -= 26;
					replace = true;
				}
			if (replace == true) {
			newString = newString + Character.toString((char) newChar);
			}
			else {
			newString = newString + Character.toString((char) firstChar);
			}
		}
		return newString;
	}
	
	public static void generateFile(File fl, String decryptedfilename, int shift) throws FileNotFoundException {
		Scanner original = new Scanner(fl);
		PrintWriter decrypted = new PrintWriter(new File("/Users/araaishpaul/Desktop/TestFiles/" + decryptedfilename));
			while (original.hasNext()) {
					String test = original.nextLine();

					decrypted.append(shift(test, shift));
					decrypted.append("\n");
			}
		decrypted.close();
	}
}

