import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class ui extends Decrypter
{
	//USER INTERFACE
	//Araaish
	public static void testFile() throws FileNotFoundException
	{
		Scanner input = new Scanner(System.in);
		
		
		System.out.println("What is the name of your Caesar-encrypted file?");
		
		String encrypted_file_name = input.nextLine();
		
		File encrypted_file = new File("/Users/araaishpaul/Desktop/TestFiles/" + encrypted_file_name);
		
		
		Boolean solveMethodbool = true;
		while(solveMethodbool)
		{
		System.out.println("Would you like the Magic Caesar Decoder to autoSolve or would you like to suggest a key?");
		String solveMethod = input.nextLine();
		
		if (solveMethod.equals("autoSolve"))
		{
			autoSolve(encrypted_file);
			solveMethodbool = false;
		}
		if (solveMethod.equals("suggest a key"))
		{
			keyedSolve(encrypted_file);
			solveMethodbool = false;
		}
			
		}
		
	}
	
	//AUTOSOLVE METHOD
	//Charlie
	public static void autoSolve(File fl) throws FileNotFoundException
	{
		Scanner file_reader = new Scanner(fl);
		generateFile(fl,"decrypted_file",identify(fl));
		Scanner scan = new Scanner(new File ("/Users/araaishpaul/Desktop/TestFiles/" + "decrypted_file"));
		int counter = 0;
		while(scan.hasNext())
		{
			String str = scan.next();
			if (countSense(str))
			{
				counter ++;
			}
		}
		System.out.println("It most likely needed to be shifted by " + identify(fl) + "\nThis shift had " + counter + " common words");
		
	}	
	
	//DETERMINES IF A DECRYPTED WORD MAKES SENSE OR NOT
	//Araaish
	public static Boolean Sense(String str) throws FileNotFoundException 
	{
		Scanner srch = new Scanner (new File ("1-1000.txt"));
		
		String str2 = "";
		
		for (int i = 0; i< str.length();i++)
		{
			if (str.charAt(i) > 46)
			{
				str2 += str.charAt(i);
			}
		}
		
		while (srch.hasNext()) 
		{
			if (str2.equals(srch.next()))
			{
				return true;
			}
		}
		return false;
		
	}
	
	//RETURNS THE NUMBER OF WORDS IN FILE THAT MAKE SENSE
	//Charlie
	public static int countSense(File fl, int shift) throws FileNotFoundException 
	{
		Scanner original = new Scanner(fl);
		int count=0;
			while (original.hasNext()) {
					String test = original.next();
					if (Sense(shift(test,shift)))
						count++;
			}
		return count;
	}
	
	//RETURNS THE SHIFT THAT PRODUCES MOST SENSEMAKING DECRYPTION
	//Charlie
	public static int identify(File fl) throws FileNotFoundException 
	{
		int sensemax=0;
		int senseindex=0;
		for (int i = 0; i<26; i++) {
			if (countSense(fl, i) > sensemax) {
				sensemax = countSense(fl, i);
				senseindex = i;
			}
		}
		return senseindex;
	}

	
	
	
	//KEYEDSOLVE METHOD
	//Araaish
	public static void keyedSolve(File fl) throws FileNotFoundException
	{
		Scanner file_reader = new Scanner(fl);
		
		//get user suggested key
		System.out.println("Suggested Key: ");
		Scanner input = new Scanner(System.in);
		String key = input.next();
		
		//generate 26 element alphabet array
		int[] arr = new int[26];
		//find letter shifts
		for (int i = 0; i<key.length();i++)
		{
			arr[i] = (key.charAt(i));
		}
		int count = 97; //range of lowercase: 97-122
		
		for(int i = key.length(); i< arr.length; i++)
		{
			while (key.indexOf(count) >= 0)
			{
				
					count++;
				
			}
			
			arr[i] = count;
			count++;
		}
		
		//produce decrypted file using key
		//Araaish
		File decrypted_file = new File ("/Users/araaishpaul/Desktop/TestFiles/" + "decrypted_file");
		PrintWriter decrypted = new PrintWriter(decrypted_file);
		Scanner fileReader = new Scanner (fl);
		while (fileReader.hasNext()) {
				String test = fileReader.nextLine();
				int length = test.length();
				int i = 0;
				while (i < length) {
					if ((test.toLowerCase().charAt(i) > 96) && (test.toLowerCase().charAt(i) < 123)){
						
						boolean found = false;
						int index = 0;
						int j = 0;
						while (found == false) {
							if ((test.toLowerCase().charAt(i)==arr[j])){
								index = j;
								found = true;
							}
							j++;
						}
						decrypted.append(Character.toString((char) (index + 97)));

						}
					
					else {
						decrypted.append(Character.toString((char) test.toLowerCase().charAt(i)));
					}
					i++;
				}
				decrypted.append("\n");
		}
	decrypted.close();

	
	//count common english words and print decrypted text to console
	//Araaish
	Scanner scan = new Scanner(decrypted_file);
	int counter = 0;
	while(scan.hasNext())
	{
		String str = scan.next();
		System.out.print(str);
		System.out.print(" ");
		if (countSense(str))
		{
			counter ++;
		}
		
	}
	
	//display results
	System.out.println();
	System.out.print("Number of common English words: " + counter);
	
	}
	
	//boolean method that dtermines if a decrypted word makes sense or not
	//Araaish
	public static Boolean countSense(String str) throws FileNotFoundException 
	{
		Scanner srch = new Scanner (new File ("1-1000.txt"));
		
		String str2 = "";
		
		for (int i = 0; i< str.length();i++)
		{
			if (str.charAt(i) > 46)
			{
				str2 += str.charAt(i);
			}
		}
		
		while (srch.hasNext()) 
		{
			if (str2.equals(srch.next()))
			{
				return true;
			}
		}
		return false;
		
	}
	
	
	
	public static void displayResults() //print correct shift; print decrypted file to console
	{
		
	}
	
	/*TESTING INFO:
	 * The encrypted file should be located in the desktop file called "TestFiles".
	 * The encrypted filename is "test.txt"
	 * The decrypted version will appear in the folder as "decrypted_file"
	 * If you test the "suggest a key" feature, the test key is "brotha"
	 */
	
	public static void main(String[] args) throws FileNotFoundException
	{
	
	testFile();
	
	}
}
